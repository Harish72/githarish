package com.payment.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Objects;

public class BankPayment {

    private String name;

    private String routingNumber;

    private String accountNUmber;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoutingNumber() {
        return routingNumber;
    }

    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }

    public String getAccountNUmber() {
        return accountNUmber;
    }

    public void setAccountNUmber(String accountNUmber) {
        this.accountNUmber = accountNUmber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BankPayment that = (BankPayment) o;
        return Objects.equals(name, that.name) &&
                Objects.equals(routingNumber, that.routingNumber) &&
                Objects.equals(accountNUmber, that.accountNUmber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, routingNumber, accountNUmber);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("BankPayment{");
        sb.append("name='").append(name).append('\'');
        sb.append(", routingNumber='").append(routingNumber).append('\'');
        sb.append(", accountNUmber='").append(accountNUmber).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static void main(String[] args) throws JsonProcessingException {

        PaymentMethod paymentMethod = new PaymentMethod();
        paymentMethod.setPaymentType(PaymentType.BANK);
        BankPayment bankPayment = new BankPayment();
        bankPayment.setAccountNUmber("12344566");
        bankPayment.setName("harish");
        bankPayment.setRoutingNumber("234567");
        paymentMethod.setBankPayment(bankPayment);

        ObjectMapper mapper = new ObjectMapper();
        System.out.println(mapper.writeValueAsString(paymentMethod));

    }
}
