package com.payment.model;

import java.util.HashSet;
import java.util.Set;

public class PaymentTypesResponse {

    private Set<BankPayment> banks = new HashSet<>();

    private Set<CreditCardPayment> cards = new HashSet<>();


    public Set<BankPayment> getBanks() {
        return banks;
    }

    public void setBanks(Set<BankPayment> banks) {
        this.banks = banks;
    }

    public Set<CreditCardPayment> getCards() {
        return cards;
    }

    public void setCards(Set<CreditCardPayment> cards) {
        this.cards = cards;
    }
}
