package com.payment.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethod {

    private PaymentType paymentType;

    private BankPayment bankPayment;

    private CreditCardPayment creditCardPayment;


    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public BankPayment getBankPayment() {
        return bankPayment;
    }

    public void setBankPayment(BankPayment bankPayment) {
        this.bankPayment = bankPayment;
    }

    public CreditCardPayment getCreditCardPayment() {
        return creditCardPayment;
    }

    public void setCreditCardPayment(CreditCardPayment creditCardPayment) {
        this.creditCardPayment = creditCardPayment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PaymentMethod that = (PaymentMethod) o;
        return paymentType == that.paymentType &&
                Objects.equals(bankPayment, that.bankPayment) &&
                Objects.equals(creditCardPayment, that.creditCardPayment);
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentType, bankPayment, creditCardPayment);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PaymentMethod{");
        sb.append("paymentType=").append(paymentType);
        sb.append(", bankPayment=").append(bankPayment);
        sb.append(", creditCardPayment=").append(creditCardPayment);
        sb.append('}');
        return sb.toString();
    }
}
