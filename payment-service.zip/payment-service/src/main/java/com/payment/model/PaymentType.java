package com.payment.model;

public enum PaymentType {

    /** CREDIT_CARD type. */
    CREDITCARD,

    BANK
}
