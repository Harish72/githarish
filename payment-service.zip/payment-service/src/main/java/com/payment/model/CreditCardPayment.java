package com.payment.model;

import java.util.Objects;

public class CreditCardPayment {

    private String name;

    private String cardNumber;

    private String expirationDate;

    private String cvv;

    private String zipCode;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CreditCardPayment that = (CreditCardPayment) o;
        return Objects.equals(name, that.name) &&
                Objects.equals(cardNumber, that.cardNumber) &&
                Objects.equals(expirationDate, that.expirationDate) &&
                Objects.equals(cvv, that.cvv) &&
                Objects.equals(zipCode, that.zipCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, cardNumber, expirationDate, cvv, zipCode);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CreditCardPayment{");
        sb.append("name='").append(name).append('\'');
        sb.append(", cardNumber='").append(cardNumber).append('\'');
        sb.append(", expirationDate='").append(expirationDate).append('\'');
        sb.append(", cvv='").append(cvv).append('\'');
        sb.append(", zipCode='").append(zipCode).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
