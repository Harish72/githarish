package com.payment.controller;

import ch.qos.logback.core.util.FileUtil;
import com.payment.model.*;
import org.apache.commons.io.FileUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;

@RequestMapping(value = "/payment")
@RestController
public class PaymentController {

    private static final Set<CreditCardPayment> CARD_PAYMENT_TYPES = new HashSet<>();

    private static final Set<BankPayment> BANK_PAYMENT_TYPES = new HashSet<>();

    @PostMapping
    public ResponseEntity<PaymentMethod> savePaymentType(@RequestBody PaymentMethod paymentMethod) {

        if (paymentMethod.getPaymentType().equals(PaymentType.BANK)) {
            BANK_PAYMENT_TYPES.add(paymentMethod.getBankPayment());
        }

        if (paymentMethod.getPaymentType().equals(PaymentType.CREDITCARD)) {
            BANK_PAYMENT_TYPES.add(paymentMethod.getBankPayment());
        }
       return  ResponseEntity.ok(paymentMethod);
    }


    @DeleteMapping(value = "/{cardNo}/{type}")
    public ResponseEntity<HttpStatus> removePayment(@PathVariable(value = "cardNo") String cardNo, @PathVariable(value = "type") PaymentType paymentType) {

        if (paymentType.equals(PaymentType.BANK)) {
          BANK_PAYMENT_TYPES.removeIf(b -> b.getAccountNUmber().equals(cardNo));
        }

        if (paymentType.equals(PaymentType.CREDITCARD)) {
            CARD_PAYMENT_TYPES.removeIf(b -> b.getCardNumber().equals(cardNo));
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<PaymentTypesResponse> getPayments() {
      PaymentTypesResponse paymentTypesResponse = new PaymentTypesResponse();
         paymentTypesResponse.setBanks(BANK_PAYMENT_TYPES);
        paymentTypesResponse.setCards(CARD_PAYMENT_TYPES);
        return  new ResponseEntity<>(paymentTypesResponse, HttpStatus.OK);
    }
}
