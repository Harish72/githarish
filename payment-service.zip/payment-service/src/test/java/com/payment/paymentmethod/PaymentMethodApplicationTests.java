package com.payment.paymentmethod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMethodApplicationTests {

	@Test
	void contextLoads() {
	}

}
